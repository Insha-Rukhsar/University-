#include <iostream>
#include <fstream>
#include<cctype>
#include<string>
using namespace std;


const int MAX_ITEMS = 50;
enum RelationType { LESS, GREATER, EQUAL };

///////    name_validation     ///////////
static bool check_name(string& word)
{
    char* p = &word[0];
    if (word.empty())
    {
        return false;
    }
    else
    {
        while (*p != '\0')
        {
            if (!isalpha(*p) && *p != ' ')
            {
                return false;
            }
            if (isalpha(*p)) {
                *p = tolower(*p);
            }
            p++;
        }
        return true;
    }
}

//////    phone number validation    ////////////
static bool check_phone(string& phone)
{
    if (phone.size() != 11) return false;
    char* p = &phone[0];
    while (*p != '\0') {
        if (!isdigit(*p)) return false;
        p++;
    }
    return true;
}

//////        address validation       ////////////
static bool check_address(string& addr)
{
    if (addr.empty() || addr.size() > 50)
    {
        return false;
    }
    return true;
}

class ItemType {
public:
    ItemType()
    {
        phone_no = "";
        name = "";
        address = "";
        isValid = false; 
    }

    string getName() const { return name; }
    string getPhone() const { return phone_no; }
    string getAddress() const { return address; }
    bool getIsValid() const { return isValid; } 

    RelationType ComparedTo(ItemType otherItem) const
    {
        if (name < otherItem.name)
            return LESS;
        else if (name > otherItem.name)
            return GREATER;
        else
            return EQUAL;
    }

    void Print(ofstream& out) const
    {
        out << name << "|" << phone_no << "|" << address << endl;
    }

    bool Initialize(string n, string add, string number)
    {
        if (check_name(n) && check_phone(number) && check_address(add))
        {
            name = n;
            phone_no = number;
            address = add;
            isValid = true;
            return true;
        }
        else {
            cout << "Invalid input. Initialization failed." << endl;
            isValid = false;
            return false;
        }
    }

private:
    string phone_no;
    string name;
    string address;
    bool isValid; 
};


class  sortedType
{
public:
    sortedType();
    void MakeEmpty();
    bool IsFull() const;
    int  GetLength() const;
    ItemType RetrieveItem(ItemType& item, bool& found);
    int search(ItemType& item, bool& found);
    void InsertItem(ItemType& item);
    void DeleteItem(ItemType& item);
    void ResetList();
    bool GetNextItem(ItemType& item);
private:
    int length;
    ItemType info[MAX_ITEMS];
    int currentPos = 0;
};

sortedType::sortedType()
{
    length = 0;
}

void sortedType::MakeEmpty()
{
    length = 0;
}

bool sortedType::IsFull() const
{
    return (length == MAX_ITEMS);
}

int sortedType::GetLength() const
{
    return length;
}

void sortedType::InsertItem(ItemType& item)
{
    
    if (!item.getIsValid()) {
        cout << "Error: Cannot insert invalid item." << endl;
        return;
    }

    
    if (length >= MAX_ITEMS) {
        cout << "List is full. Cannot insert." << endl;
        return;
    }

    bool found;
    int loc = search(item, found);

    
    if (found) {
        cout << "Item already exists. Cannot insert duplicate." << endl;
        return;
    }

    int location = 0;
    while (location < length&& item.ComparedTo(info[location]) == GREATER)
    {
        location++;
    }

    for (int i = length; i > location; i--)
    {
        info[i] = info[i - 1];
    }

    info[location] = item;
    length++;
    cout << "Item inserted successfully." << endl; 
}

ItemType sortedType::RetrieveItem(ItemType& item, bool& found)
{
    
    if (!item.getIsValid()) {
        found = false;
        ItemType temp;
        return temp;
    }

    int location = search(item, found);

    if (found)
    {
        return info[location];
    }
    else
    {
        ItemType temp;
        return temp;
    }
}

int sortedType::search(ItemType& item, bool& found)
{
    
    if (!item.getIsValid()) {
        found = false;
        return -1;
    }

    bool moreToSearch;
    int location = 0;
    found = false;

    moreToSearch = (location < length);

    while (moreToSearch && !found)
    {
        switch (item.ComparedTo(info[location]))
        {
        case LESS:
            moreToSearch = false;
            break;
        case EQUAL:
            found = true;
            return location;
            break;
        case GREATER:
            location++;
            moreToSearch = (location < length);
            break;
        }
    }
    return -1;
}

void sortedType::DeleteItem(ItemType& item)
{
   
    if (!item.getIsValid()) {
        cout << "Error: Cannot delete invalid item." << endl;
        return;
    }

    bool found = false;
    int location = search(item, found);

    if (location != -1)
    {
        for (int i = location; i < length - 1; i++)
        {
            info[i] = info[i + 1];
        }
        currentPos = -1;
        length--;
        cout << "Item deleted successfully." << endl;
    }
    else
    {
        cout << "Value not found. Can't delete." << endl;
    }
}

void sortedType::ResetList()
{
    currentPos = -1;
}

bool sortedType::GetNextItem(ItemType& item)
{
    
    if (currentPos < length - 1)
    {
        currentPos++;
        item = info[currentPos];
        return true;
    }
    return false;
}

int main() {
    sortedType myList;
    int choice;
    string name, phone, address;

    do {
        cout << "\n===== MENU =====\n";
        cout << "1. Insert Item\n";
        cout << "2. Delete Item\n";
        cout << "3. Search Item\n";
        cout << "4. Display All Items\n";
        cout << "5. Save to File \n";
        cout << "6. Load from File\n";
        cout << "7. Check if List is Full\n";
        cout << "8. Make List Empty\n";
        cout << "9. Get List Length\n";
        cout << "10. Exit\n";
        //////////      checking that the input is only int  /////////
        while (true) {
            cout << "Enter your choice: ";
            if (!(cin >> choice)) {  
                cout << "Invalid input! Please enter a number.\n";
                cin.clear(); 
                cin.ignore(1000, '\n'); 
                continue; 
            }
            cin.ignore(1000, '\n'); 
            break; 
        }


        /////    insert item   //////
        if (choice == 1) {
            cout << "Enter name: ";
            getline(cin, name);
            cout << "Enter phone: ";
            getline(cin, phone);
            cout << "Enter address: ";
            getline(cin, address);

            ItemType item;
            
            if (item.Initialize(name, address, phone)) {
                myList.InsertItem(item);
            }
          
        }

        ////////      delete item ///////
        else if (choice == 2) {
            cout << "Enter name to delete: ";
            getline(cin, name);
            ItemType item;
            
            if (item.Initialize(name, "temp", "00000000000")) {
                myList.DeleteItem(item);
            }
            
        }
        /////////   search item  /////////////
        else if (choice == 3) {
            cout << "Enter name to search: ";
            getline(cin, name);
            ItemType item;
            
            if (item.Initialize(name, "temp", "00000000000")) {
                bool found;
                ItemType result = myList.RetrieveItem(item, found);
                if (found) {
                    cout << "Item found:\n";
                    cout << "Name: " << result.getName()
                        << ", Phone: " << result.getPhone()
                        << ", Address: " << result.getAddress() << endl;
                }
                else {
                    cout << "Item not found.\n";
                }
            }
            
        }

        ////////        display all items ////////////
        else if (choice == 4)
        {
            cout << "All items in sorted order:\n";
         
            if (myList.GetLength() == 0) {
                cout << "List is empty.\n";
            }
            else {
                myList.ResetList();
                ItemType item;
                while (myList.GetNextItem(item)) {
                    cout << "Name: " << item.getName()
                        << ", Phone: " << item.getPhone()
                        << ", Address: " << item.getAddress() << endl;
                }
            }
        }
        //////       saving from file        ///////////

        else if (choice == 5) {
            
            if (myList.GetLength() == 0) {
                cout << "List is empty. Nothing to save.\n";
            }
            else {
                ofstream outFile("data.txt");
                if (outFile.is_open()) {
                    myList.ResetList();
                    ItemType item;
                    int savedCount = 0;
                    while (myList.GetNextItem(item)) {
                        item.Print(outFile);
                        savedCount++;
                    }
                    outFile.close();
                    cout << savedCount << " items appended to file.\n";
                }
                else {
                    cout << "Error: Could not open file for writing.\n";
                }
            }
        }

        ///////////       loading from file        /////////////
        else if (choice == 6)
        {
            ifstream inFile("data.txt");
            if (inFile.is_open())
            {
                myList.MakeEmpty();
                int loadedCount = 0;
                int skippedCount = 0;

                
                while (getline(inFile, name, '|') && getline(inFile, phone, '|') && getline(inFile, address))
                {
                    ItemType item;
                 
                    if (item.Initialize(name, address, phone)) {
                        if (!myList.IsFull())
                        {
                            
                            bool found;
                            myList.search(item, found);
                            if (!found) {
                                myList.InsertItem(item);
                                loadedCount++;
                            }
                            else {
                                cout << "Skipping duplicate: " << name << endl;
                                skippedCount++;
                            }
                        }
                        else {
                            cout << "List is full. Cannot load more items.\n";
                            break;
                        }
                    }
                    else {
                        cout << "Skipping invalid item: " << name << "|" << phone << "|" << address << endl;
                        skippedCount++;
                    }
                }
                inFile.close();
                cout << "Loaded " << loadedCount << " items from file.\n";
                if (skippedCount > 0) {
                    cout << "Skipped " << skippedCount << " invalid/duplicate items.\n";
                }
            }
            else {
                cout << "Error: Could not open file for reading.\n";
            }
        }
        ////////////////         check the list is full   ///////
        else if (choice == 7) {
            if (myList.IsFull()) 
            {
                cout << "The list is full.\n";
            }
            else {
                cout << "The list is not full.\n";
            }
        }

        ////////        make list empty      /////
        else if (choice == 8) {
            myList.MakeEmpty();
            cout << "The list is now empty.\n";
        }
        ///////   get length   ////////
        else if (choice == 9) {
            cout << "The list currently has " << myList.GetLength() << " items.\n";
        }

        else if (choice == 10) {
            cout << "Exiting program...\n";
        }
        else 
        {
            
            cout << "Invalid choice. Please enter a number between 1-10.\n";
        }

    } while (choice != 10);

    return 0;
}