#include <iostream>
#include <fstream>
#include <cctype> 
#include <string>
using namespace std;


const int MAX_ITEMS = 50;
enum RelationType { LESS, GREATER, EQUAL };

class ItemType {
public:
    ItemType()
    {
        value = ' ';
    }

    RelationType ComparedTo(ItemType otherItem) const
    {
        if (value < otherItem.value)
            return LESS;
        else if (value > otherItem.value)
            return GREATER;
        else
            return EQUAL;
    }

    void Print(ofstream& out) const
    {
        out << value << " ";
    }

    void Initialize(char letter)
    {
        value = letter;
    }
    char GetValue() const
    {
        return value;
    }

private:
    int value;
};


class FullStack
{
};
class EmptyStack
{
};

class StackType
{
private:
    int top;
    ItemType items[MAX_ITEMS];
public:
    StackType()
    {
        top = -1;
    }
    ItemType Top()
    {
        if (IsEmpty())
            throw EmptyStack();
        return items[top];
    }
    bool IsEmpty() const
    {
        return(top == -1);
    }

    bool IsFull() const
    {
        return (top == MAX_ITEMS - 1);
    }

    void Push(ItemType newItem)
    {
        if (IsFull())
            throw FullStack();
        top++;
        items[top] = newItem;
    }

    void Pop()
    {
        if (IsEmpty())
            throw EmptyStack();
        top--;
    }


};

int precedence(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/'|| op == '%') return 2;
    if (op == '^') return 3;
    return 0;
}

bool isOperator(char c) {
    if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^' || c == '%')
    {
        return true;
    }
    
    return false;
}

string reverseString(const string& s)
{
    string temp;
    int n = s.length();
    for (int i = n - 1; i >= 0; i--)
    {
        temp += s[i];
    }
    return temp;
}

//-----------------  Infix -> Postfix using StackType -----------------
string infixToPostfix(const string& infix) {
    StackType st;
    string output;

    for (int i = 0; i < infix.length(); ++i)

    {

        char c = infix[i];
        if (isalnum(c)) 
        {
            output += c;   // operand goes straight to output
        }
        else if (c == '(') 
        {
            ItemType item;
            item.Initialize(c);
            st.Push(item);
        }
        else if (c == ')')
        {
            while (!st.IsEmpty() && st.Top().GetValue() != '(') 
            {
                output += st.Top().GetValue();
                st.Pop();
            }
            if (!st.IsEmpty()) st.Pop(); // remove '('
        }
        else if (isOperator(c)) 
        {
            while (!st.IsEmpty() && precedence(st.Top().GetValue()) >= precedence(c)) 
            {
                output += st.Top().GetValue();
                st.Pop();
            }
            ItemType item; item.Initialize(c);
            st.Push(item);
        }
    }

    while (!st.IsEmpty())
    {
        output += st.Top().GetValue();
        st.Pop();
    }

    return output;
}

string infixToPrefix(const string& infix)
{
  
    string rev = reverseString(infix);    
    for (int i = 0; i < (int)rev.length(); i++)
    {
        if (rev[i] == '(')
            rev[i] = ')';
        else if (rev[i] == ')')
            rev[i] = '(';
    }

    string temp = infixToPostfix(rev);
    temp = reverseString(temp);         
    return temp;
}
int main()
{
    cout << "================ Infix Expression Converter ================\n";

    while (true)
    {
        // -------- Step 1: Run or Quit --------
        cout << "\nMenu:\n";
        cout << "  1. Run Converter\n";
        cout << "  2. Quit\n";
        cout << "Select option: ";

        int mainChoice;
        cin >> mainChoice;
        cin.ignore();  // clear newline so getline works

        switch (mainChoice)
        {
        case 1:   // Run converter
        {
            // -------- Step 2: Get infix input --------
            string infix;
            cout << "\nEnter an infix expression: ";
            getline(cin, infix);

            // -------- Step 3: Choose conversion --------
            cout << "\nChoose output type:\n";
            cout << "  1. Postfix only\n";
            cout << "  2. Prefix only\n";
            cout << "  3. Both prefix and postfix\n";
            cout << "Selection: ";

            int convChoice;
            cin >> convChoice;
            cin.ignore();

            try
            {
                switch (convChoice)
                {
                case 1:
                    cout << "Postfix: " << infixToPostfix(infix) << "\n";
                    break;

                case 2:
                    cout << "Prefix : " << infixToPrefix(infix) << "\n";
                    break;

                case 3:
                    cout << "Postfix: " << infixToPostfix(infix) << "\n";
                    cout << "Prefix : " << infixToPrefix(infix) << "\n";
                    break;

                default:
                    cout << "Invalid conversion choice.\n";
                    break;
                }
            }
            catch (const FullStack&)
            {
                cerr << "Error: Stack overflow during conversion.\n";
            }
            catch (const EmptyStack&)
            {
                cerr << "Error: Tried to pop from an empty stack.\n";
            }
            break;
        }

        case 2:   // Quit
            cout << "Goodbye!\n";
            return 0;

        default:
            cout << "Invalid menu choice. Please enter 1 or 2.\n";
            break;
        }
    }
}
